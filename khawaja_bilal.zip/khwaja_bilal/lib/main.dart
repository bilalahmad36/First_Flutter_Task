import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Khwaja Bidding Page',
      theme: ThemeData(
        primarySwatch: Colors.orange,
      ),
      home: MaximumBid(),
    );
  }
}

class MaximumBid extends StatefulWidget {
  @override
  _MaximumBidState createState() => _MaximumBidState();
}

class _MaximumBidState extends State<MaximumBid> {

  double _currentBid = 0.0;

  void _increaseBid() {
    setState(() {
      _currentBid += 50.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Khwaja Bidding Page',
          style: TextStyle(color: Colors.white), // Title color changed to white
        ),
        backgroundColor: Colors.redAccent, // AppBar background color changed
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min, // Adjust to fit content
          crossAxisAlignment: CrossAxisAlignment.start, // Aligns content to the left
          children: [
            Text(
              'Your Current Maximum Bid:',
              style: TextStyle(fontSize: 20, color: Colors.black87), // Text color changed
            ),
            SizedBox(height: 20),
            Text(
              '\$${_currentBid.toStringAsFixed(2)}',
              style: TextStyle(
                fontSize: 40,
                fontWeight: FontWeight.bold,
                color: Colors.green, // Bid amount text color changed to green
              ),
            ),
            SizedBox(height: 25),
            Align(
              alignment: Alignment.centerRight, // Align button to the right
              child: ElevatedButton(
                onPressed: _increaseBid,
                style: ElevatedButton.styleFrom(

                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10), // Button padding
                ),
                child: Text(
                  'Increase Bid by \$50',
                  style: TextStyle(color: Colors.blue), // Button text color
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

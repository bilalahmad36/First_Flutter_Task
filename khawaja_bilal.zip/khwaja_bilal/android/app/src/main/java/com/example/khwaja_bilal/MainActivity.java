package com.example.khwaja_bilal;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
